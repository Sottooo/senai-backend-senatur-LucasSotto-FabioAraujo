﻿using Senai.Senatur.WebApi.Domains;
using Senai.Senatur.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Senatur.WebApi.Repository
{
    public class UsuarioRepository : IUsuarioRepository
    {

        SenaturContext ctx = new SenaturContext();

        public Usuarios BuscarPorEmailSenha(string email, string senha)
        {
            return ctx.Usuarios.FirstOrDefault(e => e.Email == email && e.Senha == senha);
        }


        public Usuarios BuscarPorId(int id)
        {
            return ctx.Usuarios.Include(u => u.IdTipoUsuarioNavigation).FirstOrDefault(u => u.IdUsuario == id);
        }
        public List<Usuarios> Listar()
        {
            return ctx.Usuarios.Include(t => t.IdTipoUsuarioNavigation).ToList();
        }
    }
}
