﻿using Senai.Senatur.WebApi.Domains;
using Senai.Senatur.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Senatur.WebApi.Repository
{
    public class TipoUsuarioRepository : ITipoUsuarioRepository
    {
        SenaturContext ctx = new SenaturContext();

        public TipoUsuario BuscarPorId(int id)
        {
            return ctx.TiposUsuario.FirstOrDefault(tu => tu.IdTipoUsuario == id);
        }
        public List<TipoUsuario> Listar()
        {
            return ctx.TiposUsuario.ToList();
        }
    }
}

