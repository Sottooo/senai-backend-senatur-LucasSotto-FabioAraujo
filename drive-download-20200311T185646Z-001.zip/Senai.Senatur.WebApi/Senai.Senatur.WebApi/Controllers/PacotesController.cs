﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.Senatur.WebApi.Domains;
using Senai.Senatur.WebApi.Interfaces;
using Senai.Senatur.WebApi.Repository;

namespace Senai.Senatur.WebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [ApiController]
    public class PacotesController : ControllerBase
    {
        private IPacotesRepository _pacotesRepository;
        public PacotesController()
        {
            _pacotesRepository = new PacotesRepository();
        }
      
        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_pacotesRepository.Listar());
        }
     
        [HttpGet("{id}")]
        public IActionResult BuscarporId(int id)
        {
            return Ok(_pacotesRepository.BuscarPorId(id));
        }
      
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Cadastrar(Pacotes novoPacote)
        {
            try
            {
                _pacotesRepository.Cadastrar(novoPacote);
                return StatusCode(201);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
   
        [Authorize(Roles = "1")]

        [HttpPut("{id}")]
        public IActionResult Alterar(int id, Pacotes pacoteAlterado)
        {
            Pacotes pacoteBuscado = _pacotesRepository.BuscarPorId(id);
            if (pacoteBuscado == null)
            {
                return NotFound
                    (
                        new
                        {
                            mensagem = "pacote não encontrado",
                            erro = true
                        }
                    );
            }
            return Ok("alterado");
        }
    
        [HttpDelete("{id}")]
        public IActionResult Deletar(int id)
        {
            _pacotesRepository.Deletar(id);

            return Ok("pacote deletado");
        }
    }
}