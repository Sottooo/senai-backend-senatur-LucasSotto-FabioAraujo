-- DML

-- USA BANCO DE DADOS
USE Senatur_tarde;

-- INSERE VALORES NA TABELA DE TIPOS DE USUARIO
INSERT INTO TipoUsuario (Titulo)
VALUES		('Administrador'), ('Cliente');

-- INSERE VALORES NA TABELA DE USUARIOS
INSERT INTO Usuarios (Email, Senha, IdTipoUsuario)
VALUES ('admin@admin.com', 'admin', 1), ('cliente@cliente.com', 'cliente', 2);

-- INSERE VALORES NA TABELA DE PACOTES
INSERT INTO Pacotes (NomePacote, Descricao, DataIda, DataVolta, Valor, NomeCidade, Ativo)
VALUES ('Resorts na Bahia Litoral - 5 DIAS / 4 DI�RIAS' , 'O que n�o falta em Salvador s�o
atra��es. Prova disso s�o as praias, os museus e as constru��es seculares que d�o um charme mais que
especial � regi�o. A cidade, sin�nimo de alegria, tamb�m � conhecida pela efervesc�ncia cultural que a
credenciou como um dos destinos mais procurados por turistas brasileiros e estrangeiros. O Pelourinho e
o Elevador s�o alguns dos principais pontos de visita��o' , '14/05/2020' , '18/05/2020' , '1826.00' , 'Bahia' , 1 ),

('Salvador - 5 DIAS / 4 DI�RIAS' , 'O que n�o falta em Salvador s�o atra��es. Prova disso s�o as praias, os
museus e as constru��es seculares que d�o um charme mais que especial � regi�o. A
cidade, sin�nimo de alegria, tamb�m � conhecida pela efervesc�ncia cultural que a
credenciou como um dos destinos mais procurados por turistas brasileiros e
estrangeiros. O Pelourinho e o Elevador s�o alguns dos principais pontos de visita��o.' , '06/08/2020' , '10/08/2020' , '854.00' , 'Salvador' , 1),('BONITO VIA CAMPO GRANDE - 1, PASSEIO - 5 DIAS / 4 DI�RIAS' , 'Localizado no estado de Mato Grosso do
Sul e ao sul do Pantanal, Bonito possui centenas de cachoeiras, rios e lagos de �guas
cristalinas, al�m de cavernas inundadas, pared�es rochosos e uma infinidade de peixes.
Os aventureiros costumam render-se facilmente a esse destino regado por trilhas
ecol�gicas, passeios de bote e descidas de rapel pelas in�meras quedas da �gua da
regi�o' , '28/03/2020' , '01/04/2020' , '1004.00', 'Bonito' , 1);
